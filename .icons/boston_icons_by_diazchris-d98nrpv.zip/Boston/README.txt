  BOSTON - Icon theme for GNOME
 ·······························


 Boston is a highly minimalist icon theme, with a sober color palette inspired on basic hues.
 Recommended for medium and big sizes.

 It is intended to be used in GNOME version 3.16 or higher.

 Do you love my work? Then, please, buy me a coffee! :D
 PayPal donations to: https://www.paypal.me/ChrisDiaz 
 
 Thanks!



 +++/// PRIORITIES AND SCHEDULE POINTS

 1. Main system folders
 2. Main and generic file types
 3. Main monochrome icons (primarily used by GNOME and GTK3 adapted apps)
 4. App icons that are outdated or obsolete (low resolution, for example)
 5. Rest of collection (priority for important or most used things)

 =================================================================================


 +++/// HOW TO INSTALL

 Copy entire icon theme folder into your " /home/.icons " folder 


 //////////////////////////////////////////////////////
 ***;;;/// MADE BY CHRIS D. / diazchris.deviantart.com


